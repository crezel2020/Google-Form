package com.example.finaltry;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Page4 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page4);
    }
    public void openActivity4(View v)
    {
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
    }
    public void ExitActivity()
    {
        finish();
    }
}