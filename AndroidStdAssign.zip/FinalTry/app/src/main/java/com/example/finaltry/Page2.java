package com.example.finaltry;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class Page2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page2);
    }
    public void openActivity2(View v) {
        Toast.makeText(this, "Opening Directions", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this, Page3.class);
        startActivity(intent);
    }
}